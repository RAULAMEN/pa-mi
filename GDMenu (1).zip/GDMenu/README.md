# GDMenu — mod menu propio para Geometry Dash (sin Geode)

Se instala copiando **un archivo** (`XInput9_1_0.dll`) junto a `GeometryDash.exe`.
Se abre con **TAB** o **INSERT**. Para desinstalar, borra el archivo.

## 1. Compilar (necesitas una DLL, el codigo fuente no se ejecuta solo)
**Opcion A, sin instalar nada (GitHub Actions):**
1. Crea un repositorio en GitHub y sube esta carpeta tal cual.
2. Pestana *Actions* -> ejecuta *build* -> descarga el artefacto.

**Opcion B, en tu PC:** Visual Studio 2022 (carga de trabajo C++) y CMake:
```
cmake -B build -A Win32
cmake --build build --config Release
```
La DLL queda en `build/Release/XInput9_1_0.dll`.

## 2. Que version (32 o 64 bits)
Abre GD, Administrador de tareas -> pestana Detalles. Si `GeometryDash.exe` pone "(32 bits)" usa `Win32`; si no, `x64`.
Usa el artefacto/compilacion que coincida.

## 3. Instalar
Copia `XInput9_1_0.dll` a la carpeta de GD (donde esta `GeometryDash.exe`). No lo uses a la vez que Geode
(Geode usa ese mismo nombre de DLL): si tienes Geode, quitalo o cambia el nombre del proxy.

## Funciones incluidas (no dependen de la version del juego)
- Speedhack (0.1x a 5x), guardado en `gdmenu.ini`
- Contador de FPS

## Funciones que dependen de la version (noclip, etc.)
Necesitan direcciones de memoria (offsets) especificas de cada version de GD (2.2081, 2.209...).
Se anaden en `drawMenu()` de `src/overlay.cpp` con un parche de bytes o un hook de MinHook sobre la funcion correspondiente.
